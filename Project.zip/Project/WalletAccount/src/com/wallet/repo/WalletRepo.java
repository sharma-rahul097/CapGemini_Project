package com.wallet.repo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.CustomerNotFoundException;
import com.wallet.exception.DuplicatePhoneException;


public class WalletRepo implements IWalletRepo {

	static Map<String,Customer> hm = new HashMap<>();
	//********************************Wallet Account*******************************************************
	/*******************************************************************************************************
	 - Function Name	:	save(Customer cus)
	 - Input Parameters	:	Customer cus
	 - Return Type		:	boolean
	 - Throws			:  	DuplicatePhoneException
	 - Author			:	Rahul sharma
	 - Creation Date	:	8/02/2019
	 - Description		:	Adding Customer
	 ********************************************************************************************************/
	public boolean save(Customer cus) throws DuplicatePhoneException
	{
		if(hm.containsKey(cus.getPhone()))
		{
			throw new DuplicatePhoneException();
		}
		else
		{
		hm.put(cus.getPhone(), cus);
		return true;
	}
	}
	/*******************************************************************************************************
	 - Function Name	:	showByPhone(String phone)
	 - Input Parameters	:	String phone
	 - Return Type		:	Customer
	 - Throws			:  	CustomerNotFoundException
	 - Author			:	Rahul sharma
	 - Creation Date	:	8/02/2019
	 - Description		:	Show information through Mobile number
	 ********************************************************************************************************/
	public Customer showByPhone(String phone) throws CustomerNotFoundException
	{
			if(hm.containsKey(phone))
			{
				 return hm.get(phone);
			}
		throw new CustomerNotFoundException();
	}
	
	/*******************************************************************************************************
	 - Function Name	:	retriveAllDetails(String phone)
	 - Input Parameters	:	String phone
	 - Return Type		:	ArrayList<Transaction>
	 - Throws			:  	NA
	 - Author			:	Rahul sharma
	 - Creation Date	:	8/02/2019
	 - Description		:	return the Transaction happen between Customer List
	 ********************************************************************************************************/
	public ArrayList<Transaction> retriveAllDetails(String phone) 
	{
		return hm.get(phone).getAl();
	}
	/*******************************************************************************************************
	 - Function Name	:	saveTransaction(String mobileNo, Transaction t)
	 - Input Parameters	:	String mobileNo, Transaction t
	 - Return Type		:	boolean
	 - Throws			:  	CustomerNotFoundException
	 - Author			:	Rahul sharma
	 - Creation Date	:	8/02/2019
	 - Description		:	add the transaction happen between Customer
	 ********************************************************************************************************/
	public boolean saveTransaction(String mobileNo, Transaction t) throws CustomerNotFoundException
	{
		if(hm.containsKey(mobileNo))
		{
			hm.get(mobileNo).getAl().add(t);
			return true;
		}
		throw new CustomerNotFoundException();
	}
}
