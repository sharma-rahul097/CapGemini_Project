package com.cg.exception;

public class DuplicateIdentityException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
