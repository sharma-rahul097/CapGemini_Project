package com.cg.exception;

public class SenderIdNotExistException extends IdNotExistException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
